import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:catatan_transaksi_toko_komputer/main.dart'; // Ganti dengan nama proyek Anda

void main() {
  testWidgets('Counter increments and resets correctly',
      (WidgetTester tester) async {
    // Bangun widget dan trigger frame
    await tester.pumpWidget(MyApp());

    // Tunggu sampai semua animasi atau rendering selesai
    await tester.pumpAndSettle(); // Memastikan widget sepenuhnya dibangun

    // Verifikasi bahwa widget dengan key 'counterText' menampilkan angka awal 0.
    expect(find.byKey(const Key('counterText')),
        findsOneWidget); // Menemukan widget dengan key
    expect(find.text('0'),
        findsOneWidget); // Verifikasi angka 0 muncul pertama kali

    // Cari tombol 'Increment' berdasarkan key-nya dan tap tombol tersebut.
    await tester.tap(find.byKey(const Key('incrementButton')));
    await tester.pump(); // Trigger frame setelah aksi tap

    // Verifikasi bahwa angka counter bertambah menjadi 1.
    expect(find.text('1'), findsOneWidget);

    // Cari tombol 'Reset' berdasarkan key-nya dan tap tombol tersebut.
    await tester.tap(find.byKey(const Key('resetButton')));
    await tester.pump(); // Trigger frame setelah aksi tap

    // Verifikasi bahwa angka counter kembali menjadi 0 setelah di-reset.
    expect(find.text('0'), findsOneWidget);
  });
}
