import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Catatan Transaksi Toko Komputer',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: TransactionPage(),
    );
  }
}

class TransactionPage extends StatefulWidget {
  @override
  _TransactionPageState createState() => _TransactionPageState();
}

class _TransactionPageState extends State<TransactionPage> {
  // Daftar barang dengan harga
  final List<Map<String, dynamic>> items = [
    {'name': 'Laptop', 'price': 12000},
    {'name': 'Mouse', 'price': 150},
    {'name': 'Keyboard', 'price': 300},
    {'name': 'Monitor', 'price': 2000},
  ];

  // Daftar untuk menyimpan jumlah barang yang dibeli
  List<int> quantities = [0, 0, 0, 0];
  double totalPrice = 0.0;

  // Fungsi untuk menghitung total bayar
  void calculateTotal() {
    double total = 0;
    for (int i = 0; i < items.length; i++) {
      total += items[i]['price'] * quantities[i];
    }
    setState(() {
      totalPrice = total;
    });
  }

  // Fungsi untuk mereset transaksi
  void resetTransaction() {
    setState(() {
      quantities = [0, 0, 0, 0];
      totalPrice = 0.0;
    });
  }

  // Fungsi untuk mencetak struk
  void printReceipt() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Struk Pembelian"),
        content: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            for (int i = 0; i < items.length; i++)
              if (quantities[i] > 0)
                Text('${items[i]['name']} x${quantities[i]} = ${items[i]['price'] * quantities[i]}'),
            Divider(),
            Text('Total Bayar: Rp. ${totalPrice.toStringAsFixed(0)}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text("Tutup"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Catatan Transaksi Toko Komputer'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // List barang dan inputan jumlah
            Expanded(
              child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(items[index]['name']),
                    subtitle: Text('Harga: Rp. ${items[index]['price']}'),
                    trailing: SizedBox(
                      width: 100,
                      child: TextField(
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: 'Jumlah',
                        ),
                        onChanged: (value) {
                          setState(() {
                            quantities[index] = int.tryParse(value) ?? 0;
                          });
                          calculateTotal();
                        },
                      ),
                    ),
                  );
                },
              ),
            ),
            // Tombol Reset dan Cetak Struk
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton(
                  onPressed: resetTransaction,
                  child: Text('Reset'),
                ),
                ElevatedButton(
                  onPressed: printReceipt,
                  child: Text('Cetak Struk'),
                ),
              ],
            ),
            SizedBox(height: 16),
            // Menampilkan total bayar
            Text(
              'Total Bayar: Rp. ${totalPrice.toStringAsFixed(0)}',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
