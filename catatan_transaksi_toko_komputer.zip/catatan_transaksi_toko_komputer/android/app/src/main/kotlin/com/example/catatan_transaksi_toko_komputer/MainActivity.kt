package com.example.catatan_transaksi_toko_komputer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
