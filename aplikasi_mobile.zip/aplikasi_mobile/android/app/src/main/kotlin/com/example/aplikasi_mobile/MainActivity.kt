package com.example.aplikasi_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
