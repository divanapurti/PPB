import 'package:flutter/material.dart';

class InputPage extends StatelessWidget {
  const InputPage({super.key});

  @override
  Widget build(BuildContext context) {
    final TextEditingController inputController = TextEditingController();

    return Scaffold(
      appBar: AppBar(title: const Text('Input Page')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: inputController,
              decoration: const InputDecoration(labelText: 'Input something'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Save input data to database
              },
              child: const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }
}
