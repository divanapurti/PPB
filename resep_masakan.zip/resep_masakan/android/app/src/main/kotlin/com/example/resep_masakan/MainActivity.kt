package com.example.resep_masakan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
