import 'package:flutter/material.dart';
import 'database_helper.dart';
import 'add_recipe_screen.dart';

class RecipeDetailScreen extends StatelessWidget {
  final int recipeId;
  RecipeDetailScreen({required this.recipeId});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>>(
      future: _fetchRecipe(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child)
        }
      }
    )
        }
      }