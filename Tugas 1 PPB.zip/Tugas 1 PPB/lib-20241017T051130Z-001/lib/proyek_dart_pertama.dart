import 'package:intl/intl.dart';

enum TipeJabatan { direktur, manajer, kabag }

abstract class Karyawan {
  String npp; // Not nullable
  String nama; // Not nullable
  String? alamat; // Nullable
  int thnMasuk;
  int _gaji = 2900000; 
  final int UMR = 2900000; 

  final DateFormat dateFormat = DateFormat('yyyy-MM-dd HH:mm:ss');
  final NumberFormat numFormat = NumberFormat("#,###"); 

  Karyawan(this.npp, this.nama, {this.thnMasuk = 2015, this.alamat});

  void tampilkanDetail();

  // Setter untuk gaji dengan validasi UMR
  set gaji(int gaji) {
    if (gaji < UMR) {
      _gaji = UMR;
      print("Gaji tidak boleh di bawah UMR.");
    } else {
      _gaji = gaji;
    }
  }

  // Getter gaji = UMR + tunjangan
  int get gaji => _gaji + tunjangan;

  // Fungsi untuk mencatat presensi karyawan
  void presensi(DateTime jamMasuk) {
    if (jamMasuk.hour > 10) {
      print("$nama pada ${dateFormat.format(jamMasuk)} datang terlambat");
    } else {
      print("$nama pada ${dateFormat.format(jamMasuk)} datang tepat waktu");
    }
  }

  // Deskripsi karyawan
  String deskripsi({TipeJabatan? jabatan}) {
    String teks = """===================
NPP   : $npp
Nama  : $nama
Gaji  : ${numFormat.format(gaji)}  
""";
    if (alamat != null) {
      teks += "Alamat: $alamat\n";
    }
    if (jabatan != null) {
      teks += "Jabatan: ${jabatan.name}"; 
    }
    return teks;
  }

  // Tunjangan harus diimplementasikan di subclass
  int get tunjangan;
}

class Pejabat extends Karyawan {
  TipeJabatan jabatan;

  // Correcting the constructor to pass parameters correctly
  Pejabat(super.npp, super.nama, this.jabatan, {super.thnMasuk, super.alamat});

  // Override untuk tunjangan pejabat berdasarkan jabatan
  @override
  int get tunjangan {
    if (jabatan == TipeJabatan.manajer) {
      return 2500000;
    } else if (jabatan == TipeJabatan.kabag) {
      return 1500000;
    } else {
      return 5000000; 
    }
  }

  @override
  void tampilkanDetail() {
    String teks = super.deskripsi(jabatan: jabatan);
    print(teks);
  }
}

class StafBiasa extends Karyawan {
  StafBiasa(super.npp, super.nama, {super.thnMasuk, super.alamat});

  @override
  int get tunjangan => ((2023 - thnMasuk) < 5) ? 50000 : 100000;

  @override
  void tampilkanDetail() {
    String teks = super.deskripsi(); 
    print(teks);
  }
}

List<Map<String, dynamic>> dummyData() {
  return [
    {
      "npp": "A123",
      "nama": "Lars Bak",
      "thn_masuk": 2017,
      "jabatan": TipeJabatan.direktur,
      "alamat": "Semarang Indonesia"
    },
    {
      "npp": "A345",
      "nama": "Kasper Lund",
      "thn_masuk": 2018,
      "jabatan": TipeJabatan.manajer,
      "alamat": "Semarang Indonesia"
    },
    {"npp": "B231", "nama": "Guido Van Rossum", "alamat": "California Amerika"},
    {
      "npp": "B355",
      "nama": "Rasmus Lerdorf",
      "thn_masuk": 2015,
      "alamat": "Bandung Indonesia"
    },
    {
      "npp": "B456",
      "nama": "Dennis MacAlistair Ritchie",
      "jabatan": TipeJabatan.kabag,
      "alamat": "Semarang Indonesia"
    }
  ];
}

List<Karyawan> genData(List<Map<String, dynamic>> listData) {
  List<Karyawan> data = [];

  for (var dtPegawai in listData) {
    Karyawan pegawai;

    int thnMasuk = dtPegawai.containsKey('thn_masuk') ? dtPegawai['thn_masuk'] : 2015;

    if (dtPegawai.containsKey('jabatan')) {
      if (dtPegawai['jabatan'] == null) {
        print("Jabatan tidak boleh kosong untuk NPP: ${dtPegawai['npp']}");
        continue; 
      }
      pegawai = Pejabat(dtPegawai['npp'], dtPegawai['nama'], dtPegawai['jabatan'], thnMasuk: thnMasuk, alamat: dtPegawai['alamat']);
    } else {
      pegawai = StafBiasa(dtPegawai['npp'], dtPegawai['nama'], thnMasuk: thnMasuk, alamat: dtPegawai['alamat']);
    }

    data.add(pegawai);
  }

  return data;
}

void main() {
  List<Karyawan> dataKaryawan = genData(dummyData());

  // Mencatat presensi
  dataKaryawan[0].presensi(DateTime.parse('2023-08-08 07:00:00'));
  dataKaryawan[1].presensi(DateTime.parse('2023-08-08 09:01:01'));
  dataKaryawan[2].presensi(DateTime.parse('2023-08-08 08:30:00'));

  dataKaryawan[1].gaji = 50000; 
  dataKaryawan[2].gaji = 500000; 

  // Menampilkan deskripsi karyawan
  for (var staff in dataKaryawan) {
    staff.tampilkanDetail();
  }
}
